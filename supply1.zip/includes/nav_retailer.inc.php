<nav>
	<a href="../retailer/index.php">Home</a><!--
	--><a href="../retailer/view_products.php">Products</a><!--
	--><a href="../retailer/view_my_orders.php">My Orders</a><!--
	--><a href="../retailer/view_my_invoices.php">My Invoices</a>
</nav>